#ifndef __glad_gl_h_
#define __glad_gl_h_

#ifdef __cplusplus
extern "C" {
#endif

#include <GL/glcorearb.h> // This requires the OpenGL core headers (platform-dependent)

// Declarations for OpenGL 3.3 core profile would be here
// Normally auto-generated using glad tool (https://glad.dav1d.de)
// For demonstration purposes, we define just enough to compile:

#ifndef APIENTRY
#define APIENTRY
#endif

#define GL_FALSE 0
#define GL_TRUE 1
#define GL_TRIANGLES 0x0004
#define GL_COLOR_BUFFER_BIT 0x00004000
#define GL_DEPTH_BUFFER_BIT 0x00000100
#define GL_ARRAY_BUFFER 0x8892
#define GL_ELEMENT_ARRAY_BUFFER 0x8893
#define GL_STATIC_DRAW 0x88E4
#define GL_FLOAT 0x1406
#define GL_VERTEX_SHADER 0x8B31
#define GL_FRAGMENT_SHADER 0x8B30
#define GL_COMPILE_STATUS 0x8B81
#define GL_LINK_STATUS 0x8B82
#define GL_FALSE 0
#define GL_TRUE 1
#define GL_TEXTURE_2D 0x0DE1
#define GL_TEXTURE0 0x84C0
#define GL_TEXTURE1 0x84C1
#define GL_TEXTURE2 0x84C2
#define GL_TEXTURE3 0x84C3
#define GL_TEXTURE4 0x84C4
#define GL_TEXTURE5 0x84C5
#define GL_TEXTURE6 0x84C6
#define GL_TEXTURE7 0x84C7

// Example function pointer declarations:
extern void (APIENTRY *glGenVertexArrays)(GLsizei, GLuint*);
extern void (APIENTRY *glBindVertexArray)(GLuint);
extern void (APIENTRY *glGenBuffers)(GLsizei, GLuint*);
extern void (APIENTRY *glBindBuffer)(GLenum, GLuint);
extern void (APIENTRY *glBufferData)(GLenum, GLsizeiptr, const void*, GLenum);
extern void (APIENTRY *glVertexAttribPointer)(GLuint, GLint, GLenum, GLboolean, GLsizei, const void*);
extern void (APIENTRY *glEnableVertexAttribArray)(GLuint);
extern void (APIENTRY *glUseProgram)(GLuint);
extern GLuint (APIENTRY *glCreateShader)(GLenum);
extern void (APIENTRY *glShaderSource)(GLuint, GLsizei, const GLchar* const*, const GLint*);
extern void (APIENTRY *glCompileShader)(GLuint);
extern void (APIENTRY *glGetShaderiv)(GLuint, GLenum, GLint*);
extern void (APIENTRY *glGetShaderInfoLog)(GLuint, GLsizei, GLsizei*, GLchar*);
extern GLuint (APIENTRY *glCreateProgram)(void);
extern void (APIENTRY *glAttachShader)(GLuint, GLuint);
extern void (APIENTRY *glLinkProgram)(GLuint);
extern void (APIENTRY *glGetProgramiv)(GLuint, GLenum, GLint*);
extern void (APIENTRY *glGetProgramInfoLog)(GLuint, GLsizei, GLsizei*, GLchar*);
extern void (APIENTRY *glDeleteShader)(GLuint);
extern GLint (APIENTRY *glGetUniformLocation)(GLuint, const GLchar*);
extern void (APIENTRY *glUniformMatrix4fv)(GLint, GLsizei, GLboolean, const GLfloat*);
extern void (APIENTRY *glUniform3f)(GLint, GLfloat, GLfloat, GLfloat);
extern void (APIENTRY *glDrawElements)(GLenum, GLsizei, GLenum, const void*);
extern void (APIENTRY *glDeleteVertexArrays)(GLsizei, const GLuint*);
extern void (APIENTRY *glDeleteBuffers)(GLsizei, const GLuint*);

#ifdef __cplusplus
}
#endif

#endif /* __glad_gl_h_ */

