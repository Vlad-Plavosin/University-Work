import domain.Nota;
import domain.Student;
import org.junit.jupiter.api.*;
import repository.NotaXMLRepository;
import repository.StudentXMLRepository;
import repository.TemaXMLRepository;
import service.Service;
import validation.NotaValidator;
import validation.StudentValidator;
import validation.TemaValidator;
import validation.Validator;

import static org.junit.jupiter.api.Assertions.assertEquals;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class StudentTest {
    public static Service service;

    @BeforeAll
    public static void setup() {
        // Create Validators
        StudentValidator studentValidator = new StudentValidator();
        TemaValidator temaValidator = new TemaValidator();
        NotaValidator notaValidator = new NotaValidator();

        // Create XML Repositories
        StudentXMLRepository studentRepo = new StudentXMLRepository(studentValidator, "studenti.xml");
        TemaXMLRepository temaRepo = new TemaXMLRepository(temaValidator, "teme.xml");
        NotaXMLRepository notaRepo = new NotaXMLRepository(notaValidator, "note.xml");

        // Initialize Service with real repositories
        service = new Service(studentRepo, temaRepo, notaRepo);
    }

    @Test
    void testSaveValidStudent() {
        int result = service.saveStudent("1", "John", 931);
        assertEquals(1, result, "Student should be saved successfully");
        Iterable<Student> students = service.findAllStudents();
        for (Student student : students) {
            if (student.getID().equals("1")) {
                assertEquals("John", student.getNume(), "Student name should be John");
                assertEquals(931, student.getGrupa(), "Student group should be 931");
            }
        }
    }

    @Test
    void testSaveValidStudentDuplicate() {
        int result = service.saveStudent("2", "Maria", 931);
        assertEquals(0, result, "Student should not be saved successfully");
    }

    @Test
    void testSaveInvalidGroupSmaller(){
        int result = service.saveStudent("10", "Irina", 109);
        assertEquals(0, result, "Student should not be saved successfully");
    }

    @Test
    void testSaveInvalidGroupBigger(){
        int result = service.saveStudent("11", "Vlad", 939
        );
        assertEquals(0, result, "Student should not be saved successfully");
    }

    @Test
    void testSaveInvalidId(){
        int result = service.saveStudent("", "Vlad", 939
        );
        assertEquals(0, result, "Student should not be saved successfully");
    }

    @Test
    void testSaveNullId(){
        int result = service.saveStudent(null, "Vlad", 939
        );
        assertEquals(0, result, "Student should not be saved successfully");
    }

    @Test
    void testSaveInvalidName(){
        int result = service.saveStudent("11", "", 939
        );
        assertEquals(0, result, "Student should not be saved successfully");
    }

    @Test
    void testSaveNullName(){
        int result = service.saveStudent("11", null, 939
        );
        assertEquals(0, result, "Student should not be saved successfully");
    }


    @AfterAll
    void cleanup() {
        service.deleteStudent("1");
    }

}
