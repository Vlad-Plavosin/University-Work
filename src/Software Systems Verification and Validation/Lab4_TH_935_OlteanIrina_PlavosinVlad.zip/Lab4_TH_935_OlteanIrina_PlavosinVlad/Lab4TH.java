import domain.Nota;
import domain.Student;
import domain.Tema;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import repository.NotaXMLRepository;
import repository.StudentXMLRepository;
import repository.TemaXMLRepository;
import service.Service;
import validation.NotaValidator;
import validation.StudentValidator;
import validation.TemaValidator;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class Lab4TH {
    @Mock
    private StudentXMLRepository mockStudentRepo;

    @Mock
    private TemaXMLRepository mockTemaRepo;

    @Mock
    private NotaXMLRepository mockNotaRepo;

    private Service service;

    @BeforeEach
    void setup() {
        mockStudentRepo = mock(StudentXMLRepository.class);
        mockTemaRepo = mock(TemaXMLRepository.class);
        mockNotaRepo = mock(NotaXMLRepository.class);

        service = new Service(mockStudentRepo, mockTemaRepo, mockNotaRepo);
    }

    @Test
    void testAddStudent() {
        Student student = new Student("1", "Alex", 932);
        when(mockStudentRepo.save(any(Student.class))).thenReturn(null);

        int result = service.saveStudent("1", "Alex", 932);

        assertEquals(1, result);
        verify(mockStudentRepo, times(1)).save(any(Student.class));
    }

    @Test
    void testAddAssignment() {
        when(mockStudentRepo.save(any(Student.class))).thenReturn(null);
        when(mockTemaRepo.save(any(Tema.class))).thenReturn(null);

        int studentResult = service.saveStudent("2", "Maria", 933);
        int assignmentResult = service.saveTema("101", "Tema Test", 7, 5);

        assertEquals(1, studentResult);
        assertEquals(1, assignmentResult);
        verify(mockStudentRepo).save(any(Student.class));
        verify(mockTemaRepo).save(any(Tema.class));
    }

    @Test
    void testAddGrade() {
        Student mockStudent = new Student("3", "Ion", 934);
        Tema mockTema = new Tema("102", "Tema Finala", 8, 6);

        when(mockStudentRepo.findOne("3")).thenReturn(mockStudent);
        when(mockTemaRepo.findOne("102")).thenReturn(mockTema);

        when(mockNotaRepo.save(any(Nota.class))).thenReturn(null);

        int result = service.saveNota("3", "102", 9.5, 9, "Late but good");

        assertEquals(1, result);
        verify(mockNotaRepo).save(any(Nota.class));
        verify(mockStudentRepo).findOne("3");
        verify(mockTemaRepo, times(2)).findOne("102");
    }
}
