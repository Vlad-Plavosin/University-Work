import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import repository.NotaXMLRepository;
import repository.StudentXMLRepository;
import repository.TemaXMLRepository;
import service.Service;
import validation.NotaValidator;
import validation.StudentValidator;
import validation.TemaValidator;

import static org.junit.jupiter.api.Assertions.assertEquals;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class AssignmentTest {
    public static Service service;

    @BeforeAll
    public static void setup() {
        // Create Validators
        StudentValidator studentValidator = new StudentValidator();
        TemaValidator temaValidator = new TemaValidator();
        NotaValidator notaValidator = new NotaValidator();

        // Create XML Repositories
        StudentXMLRepository studentRepo = new StudentXMLRepository(studentValidator, "studenti.xml");
        TemaXMLRepository temaRepo = new TemaXMLRepository(temaValidator, "teme.xml");
        NotaXMLRepository notaRepo = new NotaXMLRepository(notaValidator, "note.xml");

        // Initialize Service with real repositories
        service = new Service(studentRepo, temaRepo, notaRepo);
    }

    @Test
    void saveValidAssignment(){
        String id = "55";
        String descriere = "Descriere";
        int deadline = 10;
        int startline = 8;
        int result = service.saveTema(id, descriere, deadline, startline);
        assertEquals(1, result, "Assignment should be saved successfully");
    }

    @Test
    void saveInvalidAssignment_NullId(){
        String id = null;
        String descriere = "Descriere";
        int deadline = 10;
        int startline = 8;
        int result = service.saveTema(id, descriere, deadline, startline);
        assertEquals(0, result, "Assignment should not be saved successfully");
    }

    @Test
    void saveInvalidAssignment_EmptyId(){
        String id = "";
        String descriere = "Descriere";
        int deadline = 10;
        int startline = 8;
        int result = service.saveTema(id, descriere, deadline, startline);
        assertEquals(0, result, "Assignment should not be saved successfully");
    }

    @Test
    void saveInvalidAssignment_NullDescriere(){
        String id = "56";
        String descriere = null;
        int deadline = 10;
        int startline = 8;
        int result = service.saveTema(id, descriere, deadline, startline);
        assertEquals(0, result, "Assignment should not be saved successfully");
    }

    @Test
    void saveInvalidAssignment_EmptyDescriere(){
        String id = "56";
        String descriere = "";
        int deadline = 10;
        int startline = 8;
        int result = service.saveTema(id, descriere, deadline, startline);
        assertEquals(0, result, "Assignment should not be saved successfully");
    }

    @Test
    void saveInvalidAssignment_DeadlineSmall(){
        String id = "56";
        String descriere = "Descriere";
        int deadline = 0;
        int startline = 8;
        int result = service.saveTema(id, descriere, deadline, startline);
        assertEquals(0, result, "Assignment should not be saved successfully");
    }

    @Test
    void saveInvalidAssignment_DeadlineBig(){
        String id = "56";
        String descriere = "Descriere";
        int deadline = 15;
        int startline = 10;
        int result = service.saveTema(id, descriere, deadline, startline);
        assertEquals(0, result, "Assignment should not be saved successfully");
    }

    @Test
    void saveInvalidAssignment_DeadlineSmallerThanStartline(){
        String id = "56";
        String descriere = "Descriere";
        int deadline = 9;
        int startline = 10;
        int result = service.saveTema(id, descriere, deadline, startline);
        assertEquals(0, result, "Assignment should not be saved successfully");
    }

    @Test
    void saveInvalidAssignment_StartlineSmall(){
        String id = "56";
        String descriere = "Descriere";
        int deadline = 10;
        int startline = 0;
        int result = service.saveTema(id, descriere, deadline, startline);
        assertEquals(0, result, "Assignment should not be saved successfully");
    }

    @Test
    void saveInvalidAssignment_StartlineBig(){
        String id = "56";
        String descriere = "Descriere";
        int deadline = 10;
        int startline = 15;
        int result = service.saveTema(id, descriere, deadline, startline);
        assertEquals(0, result, "Assignment should not be saved successfully");
    }

    @Test
    void saveInvalidAssignment_InvalidDeadline(){
        String id = "56";
        String descriere = "Descriere";
        int deadline = 155;
        int startline = 10;
        int result = service.saveTema(id, descriere, deadline, startline);
        assertEquals(0, result, "Assignment should not be saved successfully");
    }


    @AfterAll
    void cleanup() {
        service.deleteTema("55");
    }
}
