package org.example.features.search;


import net.serenitybdd.junit.runners.SerenityParameterizedRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import net.thucydides.junit.annotations.UseTestDataFrom;
import org.example.steps.serenity.Rock4USteps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

@RunWith(SerenityParameterizedRunner.class)
@UseTestDataFrom("src/test/resources/Rock4U.csv")
public class SearchByKeywordStoryDDTTest {
    @Managed
    WebDriver driver;

    @Steps
    Rock4USteps steps;

    public String TestType;
    public String Functionality;
    public String SearchTerm;
    public String Email;
    public String Password;
    public String ExpectedOutcome;

    @Test
    public void run_ddt_test() {
        if ("Search".equalsIgnoreCase(Functionality)) {
            steps.open_homepage();
            steps.search_for(SearchTerm);
            steps.verify_search_result(ExpectedOutcome);
        } else if ("Login".equalsIgnoreCase(Functionality)) {
            steps.open_homepage();
            steps.open_login_page();
            steps.login_with(Email, Password);
            steps.verify_login_result(ExpectedOutcome);
        }
    }
}
