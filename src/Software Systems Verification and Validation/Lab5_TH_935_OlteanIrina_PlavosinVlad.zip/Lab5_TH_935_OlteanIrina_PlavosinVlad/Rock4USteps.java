package org.example.steps.serenity;


import net.serenitybdd.core.annotations.findby.By;
import net.thucydides.core.annotations.Step;
import org.junit.Assert;
import org.example.pages.Rock4UPage;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Rock4USteps {

    Rock4UPage page;

    @Step
    public void open_login_page() {
        page.goToLoginPage();
    }

    @Step
    public void login_with(String email, String password) {
        page.login(email, password);
    }

    @Step
    public void verify_login_result(String expected) {
        String pageText = page.getDriver().getPageSource().toLowerCase();

        if (expected.toLowerCase().contains("successful")) {
            boolean success = pageText.contains("bine ai venit in cont");
            Assert.assertTrue("Expected login success message", success);
        } else {
            boolean failed = pageText.contains("avem 1 eroare");
            Assert.assertTrue("Expected login failure message", failed);
        }
    }


    @Step
    public void open_homepage() {
        page.openAt("https://www.rock4u.ro/");
    }

    @Step
    public void search_for(String keyword) {
        page.enterSearchTerm(keyword);
        page.submitSearch();
    }

    @Step
    public void verify_search_result(String expected) {
        String pageText = page.getDriver().getPageSource().toLowerCase();

        if (expected.toLowerCase().contains("no results")) {
            boolean noResults = pageText.contains("am gasit 0 rezultate");
            Assert.assertTrue("Expected message 'Am gasit 0 rezultate'", noResults);
        } else {
            // Cautam expresia "am gasit X rezultate" si extragem X
            Pattern pattern = Pattern.compile("am gasit (\\d+) rezultate");
            Matcher matcher = pattern.matcher(pageText);

            boolean found = matcher.find();
            Assert.assertTrue("Expected result count text not found", found);

            int resultCount = Integer.parseInt(matcher.group(1));
            Assert.assertTrue("Expected at least 1 result, but found: " + resultCount, resultCount > 0);
        }
    }

}

